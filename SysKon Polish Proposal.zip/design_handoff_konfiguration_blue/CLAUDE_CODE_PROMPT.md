# Claude-Code-Prompt — SysKon Konfiguration + Analyse politur

Lege diesen Ordner (`design_handoff_konfiguration_blue/`) irgendwo ins SysKon-Repo
(oder ziehe ihn in die Claude-Code-Session) und starte Claude Code im Repo-Wurzelverzeichnis.
Kopiere dann den folgenden Block:

---

Wir politieren zwei Seiten von SysKon in der „Blauen Richtung" (Varianten C + D):
**Konfiguration** und **Analyse**. Das ist **kein Redesign** — die App nutzt bereits die
richtigen Klassen, Fonts (IBM Plex) und Farben (`--akzent #0e5a8a`, Radius 8px). Es geht nur
um einen kleinen CSS-Politur-Patch. Alle betroffenen Klassen existieren schon in `src/styles.css`.

**Quelle der Wahrheit:** `design_handoff_konfiguration_blue/styles-polish.css` (gegen die echten
Klassennamen geschrieben) sowie die Zielbilder `reference/preview-C.png` (Konfiguration) und
`reference/preview-D.png` (Analyse). Lies zuerst `README.md` im selben Ordner.

**Aufgabe:** Führe die Regeln aus `styles-polish.css` in `src/styles.css` zusammen (bevorzugt
direkt einpflegen, kein zusätzlicher Import), sodass die bestehende Token-/Regelstruktur erhalten
bleibt.

### Teil 1 — Tokens (in `:root`)
- `--akzent-wahl: #2c79bd;` und `--akzent-wahl-flaeche: #e9f2fb;` ergänzen.
  `--akzent` bleibt Primärfarbe; `--akzent-wahl` ist nur der Auswahl-/Aktiv-Akzent.

### Teil 2 — Konfiguration (`src/screens/Konfiguration.jsx`, nur via CSS)
- `.antwort-option`: padding `10px 12px`, Grid `17px minmax(0,1fr)`, `input` `16px`.
  `.antwort-option.aktiv`: Rand + `box-shadow: inset 0 0 0 1px` auf `--akzent-wahl`,
  Fläche `--akzent-wahl-flaeche`, `.aktiv .antwort-label` Farbe `--akzent-tief`.
  `.antwort-hinweis`: `12.5px / line-height 1.4`.
- `.karte h2` → `18px` + `letter-spacing -0.005em`; `.frage-label` → `14.5px`.
- `.drei-spalten` Spalten → `200px minmax(0,1fr) 372px`, `gap 16px`; `.sektion-anker` → `13px`.
- `.tab.aktiv` Unterstrich → `--akzent-wahl`; `.preview-positionen em` → `font-weight 500`.

### Teil 3 — Analyse (`src/screens/Ergebnis.jsx`, nur via CSS)
- `.tabs-sekundaer .tab.aktiv` Unterstrich → `--akzent-wahl`.
- `.kunden-position`: Fläche → `--karte`, Rand → `--rand`, Hover: `border-color --rand-stark`
  + `box-shadow --schatten`. `.kunden-position-kopf strong` → `14px`.
- `.analyse-kpi`: Fläche → `--karte`, Rand → `--rand`; `.analyse-kpi strong` → `13.5px`.
- `.kunden-badge`: Mono-Schrift + `letter-spacing 0.02em`.
- `.kunden-gruppe h4`: `letter-spacing 0.09em`. `tr.gruppe td` bleibt `--akzent-hell`.
- **Wichtig:** `tr.gewaehlt` (Schall-Tabelle) **bleibt grün** — nicht auf Blau ändern.

### Optional (nur wenn schnell machbar)
Aktiven Abschnitt in der linken Navigation hervorheben: in `Konfiguration.jsx` per
IntersectionObserver auf die `.sek-block`-Karten die sichtbare Sektion bestimmen und dem
zugehörigen `.sektion-anker` die Klasse `aktiv` geben. CSS (`.sektion-anker.aktiv`) ist im Patch.

### Randbedingungen
- Keine neuen Abhängigkeiten, keine Font-Wechsel, `--akzent` bleibt Primärfarbe.
- Struktur der 3 Spalten, der sekundären Tabs, von `data/`, `logic/` und anderen Screens
  unverändert lassen.
- Responsive-Breakpoints (`@media`) und Druckstile in `styles.css` intakt lassen.
- Danach `npm run dev`: Konfiguration gegen `preview-C.png`, Analyse (Tab „Kundenumfang")
  gegen `preview-D.png` abgleichen. Anschließend `npm test`; bei UI-Änderung `npm run build`.

Zeig mir am Ende einen Diff von `src/styles.css` (und ggf. `Konfiguration.jsx`).
