# Handoff: Konfiguration + Analyse – „Blaue Richtung" (Variante C/D)

## Überblick
Politur der beiden Hauptseiten des Systempaket-Konfigurators (SysKon):
**Konfiguration** (Variante C) und **Analyse** (Variante D, Tab „Kundenumfang").
Ziel: ruhigere Hierarchie und klarere Auswahl-/Statuszustände – **ohne**
das vorhandene Erscheinungsbild (Navy-Topbar, Stahlblau, IBM Plex, 8px-Radius) zu verlassen.

**Wichtigste Erkenntnis:** Variante C ist **kein Redesign**. Die heutige App benutzt
bereits genau die Klassen, Fonts und Farben, die der Mock zeigt. Die Migration ist
deshalb ein **kleiner CSS-Politur-Patch** gegen `src/styles.css`, keine Umstrukturierung
und keine JSX-Änderung.

## Über die Design-Dateien
Die Dateien in `reference/` sind **HTML/JSX-Design-Referenzen** (ein Standalone-Prototyp,
der das Zielbild zeigt) – **kein** produktiv zu kopierender Code. Sie nutzen React über
Babel im Browser, isolierte `.sb`-Klassen und Demo-Inhalte. In der echten App wird **nicht**
dieser Prototyp eingebaut, sondern die unten beschriebenen Stilwerte werden auf die
**bereits existierenden** Klassen in `src/styles.css` angewandt.

## Fidelity
**High-fidelity.** Exakte Farben, Abstände, Schriftgrößen sind unten angegeben. Pixelnah
umsetzen, aber über die vorhandenen Klassen – nichts neu erfinden.

## Schnellster Weg (empfohlen)
1. `styles-polish.css` öffnen. Sie ist gegen die **echten** Klassennamen der App geschrieben.
2. Die Regeln in `src/styles.css` einpflegen (oder die Datei nach `styles.css` importieren).
3. Fertig. Kein Komponentenumbau nötig.

---

## Was sich konkret ändert (Diff gegen `src/styles.css`)

Alles andere bleibt unangetastet. Nur diese Punkte:

### 1. Neue Tokens (in `:root`)
```css
--akzent-wahl: #2c79bd;          /* kräftigerer Rand NUR für ausgewählte Radiokarte */
--akzent-wahl-flaeche: #e9f2fb;  /* Auswahlfläche, minimal kühler als --akzent-hell */
```
`--akzent` (#0e5a8a) bleibt die Primärfarbe; `--akzent-wahl` ist nur der Auswahl-Akzent.

### 2. Radiokarten `.antwort-option` (der eigentliche Politur-Schritt)
| Eigenschaft | vorher | nachher |
|---|---|---|
| `padding` | `7px 9px` | `10px 12px` |
| `grid-template-columns` | `18px minmax(0,1fr)` | `17px minmax(0,1fr)` |
| Radio-Größe (`input`) | `14px` | `16px` |
| **`.aktiv` Rand** | `var(--akzent)` | `var(--akzent-wahl)` |
| **`.aktiv` Fläche** | `var(--akzent-hell)` | `var(--akzent-wahl-flaeche)` |
| **`.aktiv` Ring** | – | `box-shadow: inset 0 0 0 1px var(--akzent-wahl)` |
| `.aktiv .antwort-label` | – | `color: var(--akzent-tief)` |
| `.antwort-hinweis` | `12px / 1.3` | `12.5px / 1.4` |

### 3. Hierarchie
- `.karte h2` (Abschnittstitel): `16px` → `18px`, `letter-spacing: -0.005em`
- `.frage-label`: → `14.5px`

### 4. Linke Navigation
- `.drei-spalten` `grid-template-columns`: `176px … 360px` → `200px … 372px`, `gap` `14px` → `16px`
- `.sektion-anker`: `font-size` `12px` → `13px`

### 5. Aktiver Abschnitt markieren (optional, neu)
- CSS für `.sektion-anker.aktiv` liegt im Patch.
- Dafür im Markup eine `aktiv`-Klasse an den aktuell sichtbaren Anker hängen
  (z. B. via IntersectionObserver auf die `.sek-block`-Karten in `Konfiguration.jsx`).
  Rein optional – ohne diesen Schritt funktioniert alles andere unverändert.

### 6. Kleinteiliges
- `.tab.aktiv` Unterstrich: `var(--akzent)` → `var(--akzent-wahl)`
- `.preview-positionen em` → `font-weight: 500` (Mengen etwas präsenter)

---

## Analyse-Seite (`src/screens/Ergebnis.jsx`)
Gleiche Politur, dieselben Tokens. Auch hier existieren alle Klassen schon. Diff:

- `.tabs-sekundaer .tab.aktiv` Unterstrich → `var(--akzent-wahl)` (wie Punkt 6)
- `.kunden-position`: Fläche `var(--hover-flaeche)` → `var(--karte)`, Rand `--rand`,
  Hover hebt mit `border-color: --rand-stark` + `box-shadow: --schatten` an
- `.analyse-kpi`: Fläche `var(--hover-flaeche)` → `var(--karte)`, Rand `--rand`
- `.kunden-badge`: Mono-Schrift + `letter-spacing: 0.02em` (Pills bleiben 999px)
- `.kunden-gruppe h4`: `letter-spacing: 0.09em`; `tr.gruppe td` bleibt `--akzent-hell`
- `tr.gewaehlt` (Schall-Tabelle) **bleibt grün** – markiert weiter die tragfähige Wahl

Alle Regeln stehen ausformuliert in `styles-polish.css` (Abschnitte 8–14).

---

## Screens
**Konfiguration** (3 Spalten, unverändert in Struktur):
- **Links:** `.sektion-nav` – Preset-Select + Abschnitte A–J mit grünen Häkchen (`--st-gruen`).
- **Mitte:** `.karte.sek-block` je Sektion; Fragen als `.antwort-liste` (Radiokarten) bzw.
  Zahl-Inputs; rechts daneben optionaler `.gespraechshinweis`.
- **Rechts:** `.karte.live.kunden-preview` – Status (`.ampel.gross`), `.dq-balken`,
  `.mini-fakten` (Vorlösung), `.preview-positionen` (Umfangs-Vorschau), CTA „Zur Analyse →".

**Analyse** (`Ergebnis.jsx`, unverändert in Struktur):
- `.summary-strip` (Status-Korridor) + `.tabs-sekundaer` (Kundenumfang / Vorlösung /
  Interner Umfang / Prüfpunkte).
- Tab **Kundenumfang:** `.kunden-gruppen` → `.kunden-gruppe` → `.kunden-positionen` →
  `.kunden-position` (Kopf mit `.kunden-badge` „enthalten"/„prüfen", `dl`, Leistungstext);
  darunter `.karten-reihe` mit Annahmen / Ausschlüsse / Offene Punkte.
- Weitere Tabs nutzen `.analyse-kpi`, `table.lv`, `table.fakten`, `.pruef-tabelle` – alle
  von denselben Token-Änderungen abgedeckt.

## Design-Tokens (Bestand, zur Referenz)
- Hintergrund `--bg #eef1f4` · Karte `#fff` · Rand `--rand #d3dae1`
- Text `--text #16222e` · gedämpft `--muted #5d6b78`
- Stahlblau `--akzent #0e5a8a` · tief `--akzent-tief #0b486e` · Auswahlfläche `--akzent-hell #e7f0f7`
- Topbar `--topbar #122a3c`
- Status grün `#1a7f37` / gelb `#b58105` / orange `#d4570b` / rot `#c0392b`
- Radius `8px` (groß) / `6px` (klein) · Schatten `0 1px 2px rgb(22 34 46 / .05)`
- Fonts: **IBM Plex Sans** (UI) · **IBM Plex Mono** (Zahlen/Codes)
- **NEU:** `--akzent-wahl #2c79bd` · `--akzent-wahl-flaeche #e9f2fb`

## Dateien in diesem Bundle
- `styles-polish.css` — der Patch in echter Klassen-Sprache (Konfiguration + Analyse) → in `src/styles.css` mergen
- `CLAUDE_CODE_PROMPT.md` — fertiger Prompt für Claude Code (beide Seiten)
- `reference/preview-C.png` — Zielbild Konfiguration (Sektion A)
- `reference/preview-D.png` — Zielbild Analyse (Tab Kundenumfang)
- `reference/preview-C.html`, `reference/preview-D.html` — Standalone-Prototypen (Browser öffnen)
- `reference/variation-c.jsx`, `reference/variation-d.jsx`, `reference/syskon-blue.css` — Quellen der Prototypen (nur Referenz)

## Betroffene Repo-Dateien
- `src/styles.css` — alle Stiländerungen (Konfiguration + Analyse)
- `src/screens/Konfiguration.jsx` — **nur** falls Punkt 5 (aktiver Abschnitt) umgesetzt wird
- `src/screens/Ergebnis.jsx` — **keine** strukturelle Änderung nötig (nur via CSS poliert)
