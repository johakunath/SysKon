/* Variation D — "Blaue Richtung", Analyse-Seite (Kundenumfang-Tab), poliert.
   Spiegelt src/screens/Ergebnis.jsx: summary-strip, sekundäre Tabs,
   Kundenumfang-Gruppen mit Positionskarten + Badges, Annahmen/Ausschlüsse/Offene Punkte.
   Reuse: shares the .sb skin + LogoMark from variation-c.jsx (loaded first). */

function DPos({ title, badge, hersteller, produkt, groesse, menge, text }) {
  const inc = badge === 'enthalten'
  return (
    <div className="sb-poscard">
      <div className="sb-poscard-h">
        <strong>{title}</strong>
        <span className={`sb-pill ${inc ? 'in' : 'check'}`}>{badge}</span>
      </div>
      <dl>
        <div><dt>Hersteller</dt><dd>{hersteller}</dd></div>
        <div><dt>Produkt</dt><dd>{produkt}</dd></div>
        <div><dt>Größe / Leistung</dt><dd>{groesse}</dd></div>
        <div><dt>Menge</dt><dd className="mono">{menge}</dd></div>
      </dl>
      <p>{text}</p>
    </div>
  )
}

function AnalyseD() {
  return (
    <div className="sb">
      {/* top bar */}
      <div className="sb-top">
        <div className="sb-brand">
          <span className="sb-logo-mark"><LogoMark /></span>
          <strong>Systempaket-Konfigurator</strong>
        </div>
        <div className="sb-toptabs">
          <button className="sb-toptab">Konfiguration</button>
          <button className="sb-toptab active">Analyse</button>
        </div>
        <div className="sb-top-right"><button className="sb-gear">⚙</button></div>
      </div>

      <div className="sb-seite">
        {/* summary strip */}
        <div className="sb-summary">
          <span className="sb-dot gelb" style={{ width: 22, height: 22 }}></span>
          <div className="sm-mid">
            <span className="sm-t">Gesprächskorridor: Gespräch mit offenen Klärpunkten</span>
            <span className="sm-d">4 × 20 kW · 6 Umfangsgruppen · keine Preisansicht</span>
          </div>
          <div className="sm-a">Offene Pflichtdaten und Regelhinweise priorisieren, bevor der Kundenumfang weitergegeben wird.</div>
        </div>

        {/* secondary tabs */}
        <div className="sb-subtabs">
          <button className="sb-subtab active">Kundenumfang</button>
          <button className="sb-subtab">Vorlösung</button>
          <button className="sb-subtab">Interner Umfang</button>
          <button className="sb-subtab">Prüfpunkte</button>
        </div>

        {/* Kundenumfang */}
        <div className="sb-card sb-sec" style={{ marginBottom: 14 }}>
          <h2 style={{ fontSize: 17 }}>Kundenumfang</h2>
          <p className="sb-an-lead">Verständliche Komponenten- und Leistungsübersicht für das Kundengespräch. Ohne Preise, ohne interne Kalkulation und ohne verbindlichen Angebotscharakter.</p>

          <div className="sb-group">
            <h4>Wärmeerzeugung</h4>
            <div className="sb-poscards">
              <DPos title="Luft-Wasser-Wärmepumpen-Kaskade" badge="enthalten"
                hersteller="noch offen" produkt="WP-Modul, wird später festgelegt"
                groesse="4 × 20 kW, ca. 80 kW" menge="4 Stk"
                text="Modulare Außenaufstellung als Kaskade; Produktwahl im weiteren Prozess." />
              <DPos title="Hybrid-Einbindung" badge="prüfen"
                hersteller="projektbezogen" produkt="Hydraulik- & Regelungseinbindung"
                groesse="projektbezogener Umfang" menge="1 pausch."
                text="Hydraulische und regelungstechnische Einbindung von WP und Bestandskessel." />
              <DPos title="Weiterbetrieb Bestandskessel" badge="enthalten"
                hersteller="Bestand" produkt="vorhandener Gas-Bestandskessel"
                groesse="Spitzenlast / Backup" menge="1 pausch."
                text="Bestandskessel übernimmt Spitzenlast und Redundanz im Hybridbetrieb." />
            </div>
          </div>

          <div className="sb-group">
            <h4>Hydraulik &amp; Speicher</h4>
            <div className="sb-poscards">
              <DPos title="Hydraulikpaket" badge="enthalten"
                hersteller="projektbezogen" produkt="Pumpengruppen & Regelung"
                groesse="projektbezogener Umfang" menge="1 pausch."
                text="Pumpengruppen, Regelung und hydraulische Einbindung inkl. Abgleich." />
              <DPos title="Speicher-/Warmwassermodul" badge="enthalten"
                hersteller="projektbezogen" produkt="Pufferspeicher & WW-Bereitung"
                groesse="zentrale Warmwasserbereitung" menge="1 pausch."
                text="Speicher- und Warmwasserlösung für die zentrale Versorgung." />
            </div>
          </div>
        </div>

        {/* Annahmen / Ausschlüsse / Offene Punkte */}
        <div className="sb-cards3">
          <div className="sb-minicard">
            <h3>Annahmen</h3>
            <ul className="sb-minilist">
              <li>Heizlast über Verbrauchs-Proxy (650 MWh/a) abgeleitet.</li>
              <li>Hybridpfad mit Weiterbetrieb des Bestandskessels.</li>
              <li>Außenaufstellung als Schutz-/Schall-Einhausung.</li>
            </ul>
          </div>
          <div className="sb-minicard">
            <h3>Ausschlüsse</h3>
            <div className="sb-okbox">Keine kundenseitigen Ausschlüsse im aktuellen Demo-Korridor.</div>
          </div>
          <div className="sb-minicard">
            <h3>Offene Punkte</h3>
            <ul className="sb-minilist">
              <li><strong>Heizlast:</strong> belastbare Berechnung nachreichen (R14).</li>
              <li><strong>Hybrid-Einbindung:</strong> Umfang vor Ort prüfen.</li>
              <li><strong>Netzanschluss:</strong> Leistung bestätigen.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

window.AnalyseD = AnalyseD
