/* Variation C — "Blaue Richtung", faithful to the live app, polished.
   Navy chrome · steel-blue accent · radio-card answers · Umfangs-Vorschau panel.
   Fonts: IBM Plex Sans / Mono (the app's own — deliberately not serif). */

function LogoMark() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path d="M12 3l8 4.2-8 4.2-8-4.2L12 3z" fill="#3fae8f" />
      <path d="M4 12l8 4.2 8-4.2" stroke="#9fd8c7" strokeWidth="1.6" strokeLinejoin="round" fill="none" />
      <path d="M4 16.5l8 4.2 8-4.2" stroke="#6cc3a8" strokeWidth="1.6" strokeLinejoin="round" fill="none" />
    </svg>
  )
}

function CRadioOpt({ label, hint, sel }) {
  return (
    <div className={`sb-opt${sel ? ' sel' : ''}`}>
      <span className="sb-radio"></span>
      <span className="sb-opt-text">
        <span className="sb-opt-label">{label}</span>
        <span className="sb-opt-hint">{hint}</span>
      </span>
    </div>
  )
}

function CQNum({ label, unit, value }) {
  return (
    <div className="sb-q">
      <div className="sb-q-label">{label} {unit ? <span className="unit">({unit})</span> : null}</div>
      <div className="sb-num-wrap">
        <input className="sb-num" defaultValue={value} readOnly />
        <span className="sb-stepper"><button>▲</button><button>▼</button></span>
      </div>
    </div>
  )
}

function CQRadio({ label, opts, hint }) {
  return (
    <div className="sb-q">
      <div className="sb-q-label">{label}</div>
      <div className={`sb-q-grid${hint ? ' with-hint' : ''}`}>
        <div className="sb-opts">
          {opts.map((o, i) => <CRadioOpt key={i} label={o[0]} hint={o[1]} sel={o[2]} />)}
        </div>
        {hint ? <div className="sb-hint">{hint}</div> : null}
      </div>
    </div>
  )
}

const RAIL_C = [
  ['A', 'Gebäude', 'active'], ['B', 'Wärme', 'done'], ['C', 'Bestand', 'done'],
  ['D', 'Temperatur', 'done'], ['E', 'Heizraum', 'done'], ['F', 'Aufstellung', 'done'],
  ['G', 'Schall', 'done'], ['H', 'Elektro', 'done'], ['I', 'Commercial', 'done'], ['J', 'Service', 'done'],
]

const POS_C = [
  ['Luft-Wasser-Wärmepumpen-Kaskade', 'WP-Modul, Produkt wird später festgelegt · 4 × 20 kW, ca. 80 kW', '4 Stk'],
  ['Hybrid-Einbindung', 'Hydraulische und regelungstechnische Einbindung · projektbezogener Leistungsumfang', '1 pausch.'],
  ['Weiterbetrieb Bestandskessel', 'Vorhandener Gas-Bestandskessel · projektbezogener Leistungsumfang', '1 pausch.'],
  ['Hydraulikpaket', 'Pumpengruppen, Regelung und hydraulische Einbindung · projektbezogener Leistungsumfang', '1 pausch.'],
  ['Speicher-/Warmwassermodul', 'Zentrale Warmwasserbereitung · projektbezogener Leistungsumfang', '1 pausch.'],
]

function KonfigC() {
  return (
    <div className="sb">
      {/* top bar */}
      <div className="sb-top">
        <div className="sb-brand">
          <span className="sb-logo-mark"><LogoMark /></span>
          <strong>Systempaket-Konfigurator</strong>
        </div>
        <div className="sb-toptabs">
          <button className="sb-toptab active">Konfiguration</button>
          <button className="sb-toptab">Analyse</button>
        </div>
        <div className="sb-top-right">
          <button className="sb-gear">⚙</button>
        </div>
      </div>

      {/* columns */}
      <div className="sb-cols">
        {/* left rail */}
        <aside style={{ minHeight: 0 }}>
          <div className="sb-card sb-rail">
            <select className="sb-preset" defaultValue="referenz">
              <option value="referenz">Demo-Referenzfall (70 WE, Hybrid)</option>
            </select>
            <h4>Abschnitte</h4>
            {RAIL_C.map(([id, t, st]) => (
              <a key={id} className={`sb-anchor ${st}`}>
                <span className="at"><span className="code">{id}</span><span>{t}</span></span>
                <span className={`sb-frac${st === 'done' ? ' ok' : ''}`}>{st === 'done' ? '✓' : '7/7'}</span>
              </a>
            ))}
          </div>
        </aside>

        {/* middle questionnaire */}
        <main className="sb-main">
          <div className="sb-card sb-sec">
            <h2>A · Gebäude &amp; Gesprächsrahmen</h2>
            <p className="sec-sub">Grunddaten und Gesprächsrahmen für die Vorqualifizierung.</p>

            <CQRadio
              label="Welche Gebäudesituation liegt vor?"
              hint="Innenstadt oder Blockrand verschärft Schall- und Platzprüfung."
              opts={[
                ['freistehendes Bestands-MFH', 'Typischer MVP-Standardfall mit besser prüfbarer Aufstellung.', true],
                ['verdichtete Innenstadt-/Blockrandlage', 'Mehr Schall-, Platz- und Nachbarschaftsrisiko.', false],
                ['sonstige Lage', 'Sonderlage; Annahmen im Gespräch sichtbar halten.', false],
              ]}
            />
            <CQNum label="Wie viele Wohneinheiten hat das Gebäude?" unit="WE" value="70" />
            <CQNum label="Wie groß ist die beheizte Fläche?" unit="m²" value="4000" />
            <CQRadio
              label="In welche Baujahrklasse fällt das Gebäude?"
              opts={[
                ['vor 1960', 'Oft höherer Wärmebedarf; Sanierung besonders prüfen.', false],
                ['1960–1979', 'Häufig mittlerer bis hoher Bedarf; Zustand klären.', true],
                ['1980–1994', 'Meist moderater Bedarf; Modernisierung abfragen.', false],
                ['ab 1995', 'Tendenziell besserer Standard; Werte trotzdem prüfen.', false],
              ]}
            />
          </div>
        </main>

        {/* right preview */}
        <aside style={{ minHeight: 0 }}>
          <div className="sb-card sb-prev">
            <h3>Umfangs-Vorschau</h3>
            <p className="lead">Kundensicht ohne Preise. Interne Kalkulation bleibt in der Analyse getrennt.</p>

            <div className="sb-status">
              <span className="sb-dot gelb"></span>
              <div>
                <div className="st-t">Gespräch mit offenen Klärpunkten</div>
                <div className="st-a">Offene Pflichtdaten und Regelhinweise priorisieren, bevor Umfang oder interne Kalkulation weitergegeben werden.</div>
              </div>
            </div>

            <div className="sb-dq-label">Datenlage: <strong>100 %</strong> · starke Gesprächsdaten</div>
            <div className="sb-dq"><div style={{ width: '100%' }}></div></div>

            <h4>Vorlösung</h4>
            <div className="sb-fact"><span className="k">Pfad</span><span className="v">Hybrid</span></div>
            <div className="sb-fact"><span className="k">Heizlast</span><span className="v">295 kW</span></div>
            <div className="sb-fact"><span className="k">WP-Kaskade</span><span className="v">4 × 20 kW</span></div>
            <div className="sb-fact"><span className="k">Aufstellung</span><span className="v">Schutz-/Schall-Einhausung</span></div>
            <div className="sb-fact"><span className="k">Empfohlen</span><span className="v">Schutz-/Schall-Einhausung</span></div>

            <h4>Umfangs-Vorschau</h4>
            {POS_C.map(([t, s, q]) => (
              <div key={t} className="sb-pos">
                <div><div className="p-t">{t}</div><div className="p-s">{s}</div></div>
                <div className="p-q">{q}</div>
              </div>
            ))}

            <button className="sb-btn-primary">Zur Analyse →</button>
          </div>
        </aside>
      </div>
    </div>
  )
}

window.KonfigC = KonfigC
